#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Nov 11 15:06:53 2019

@author: pauline
"""

annee = 1900

if (annee%4 == 0 and annee%100 != 0) or annee%400 == 0 :
    print('Année bissextile')
else :
    print('Année non bissextile')