#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Nov 11 15:14:23 2019

@author: pauline
"""

def annee_bissextile(n):
    if (n%4 == 0 and n%100 != 0) or n%400 == 0 :
        return True
    else :
        return False
    
date = int(input('Entrer votre année de naissance : '))
print(annee_bissextile(date))
if annee_bissextile(date):
    print('Vous êtes nés une année bissextile.')
else:
    print('Vous n\'êtes pas nés une année bissextile.')