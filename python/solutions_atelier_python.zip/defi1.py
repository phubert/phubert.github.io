#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Nov 11 14:55:38 2019

@author: pauline
"""

liste = [2,5,201,32]

# Première solution avec une boucle :
somme1 = 0
for i in liste:
    somme1 = somme1 + i
print(somme1)

# Deuxième solution avec sum :
somme2 = sum(liste)
print(somme2)